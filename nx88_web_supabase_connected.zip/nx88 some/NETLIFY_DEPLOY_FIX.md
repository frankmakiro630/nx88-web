Netlify deployment fix

The project originally contained requirements.txt for a separate local Python/PostgreSQL backend.
Netlify automatically detected that file and tried to install psycopg2-binary under Python 3.14, causing the build to fail because pg_config was unavailable.

For the Netlify version, Discord OAuth is handled by netlify/functions/discord-auth.js, so the Python backend is not required. The dependency file was renamed to requirements.local.txt and local backend files are ignored during deploy.

For Discord OAuth, set the Netlify environment variable:
DISCORD_CLIENT_SECRET=<your Discord application client secret>
