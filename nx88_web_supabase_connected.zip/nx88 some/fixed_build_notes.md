# FIXED BUILD NOTES

This build fixes the JavaScript auth fallback that produced:
`Using direct Discord connection...` followed by `Không thể kết nối máy chủ xác thực`.

## Important: configure secrets
The old Discord client secret was removed from the distributable source. Set these values on the server:
- `DISCORD_CLIENT_SECRET`
- `JWT_SECRET`

If your shared PHP host does not provide environment variables, edit `api.php` and replace:
`YOUR_DISCORD_CLIENT_SECRET_HERE`
with a newly regenerated Discord Client Secret, and replace the JWT placeholder with a long random value.

## Discord redirect URI
The Discord Developer Portal redirect URI must exactly be:
`https://celebrated-fairy-a39883.netlify.app/auth/discord/callback`

## Included fixes
- Removed insecure browser-side Discord OAuth fallback.
- Better backend error handling and HTTP/cURL diagnostics.
- Forces IPv4 for Discord cURL requests when supported.
- Added request timeouts and proper TLS verification.
- Added frontend/backend aliases for profile, stats and refund routes.
- JavaScript syntax check: passed.
- PHP syntax check: passed.
