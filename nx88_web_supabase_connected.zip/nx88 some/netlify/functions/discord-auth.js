const crypto = require('crypto');
const CLIENT_ID = '1501947066560020490';
const REDIRECT_URI = 'https://celebrated-fairy-a39883.netlify.app/auth/discord/callback';
const SUPABASE_URL = process.env.SUPABASE_URL || 'https://wueazxozrcxjnhivqqwu.supabase.co';
const SUPABASE_KEY = process.env.SUPABASE_PUBLISHABLE_KEY || 'sb_publishable_tKVsV1cLkyNS_A4oJKoANw_0iZLKeHP';

function json(statusCode, body) { return { statusCode, headers:{'Content-Type':'application/json','Cache-Control':'no-store'}, body:JSON.stringify(body) }; }
async function supabaseUpsert(discordUser, username, avatarUrl) {
  const row = { user_id: String(discordUser.id), username, avatar: avatarUrl, updated_at: new Date().toISOString() };
  const r = await fetch(`${SUPABASE_URL}/rest/v1/users?on_conflict=user_id`, {
    method:'POST', headers:{ apikey:SUPABASE_KEY, Authorization:`Bearer ${SUPABASE_KEY}`, 'Content-Type':'application/json', Prefer:'resolution=merge-duplicates,return=representation' }, body:JSON.stringify(row)
  });
  const text = await r.text(); let data=[]; try { data=text?JSON.parse(text):[]; } catch {}
  if (!r.ok) throw new Error(data.message || data.hint || text || 'Supabase upsert failed');
  return Array.isArray(data) && data[0] ? data[0] : row;
}
exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return json(405,{error:'Method not allowed'});
  try {
    const input=JSON.parse(event.body||'{}');
    if(!input.code || typeof input.code!=='string') return json(400,{error:'Missing OAuth code'});
    if(input.redirect_uri && input.redirect_uri!==REDIRECT_URI) return json(400,{error:'Invalid redirect URI'});
    const clientSecret=process.env.DISCORD_CLIENT_SECRET;
    if(!clientSecret) return json(500,{error:'Discord client secret is not configured'});
    const form=new URLSearchParams({client_id:CLIENT_ID,client_secret:clientSecret,grant_type:'authorization_code',code:input.code,redirect_uri:REDIRECT_URI});
    const tr=await fetch('https://discord.com/api/v10/oauth2/token',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:form.toString()});
    const td=await tr.json().catch(()=>({})); if(!tr.ok||!td.access_token) return json(401,{error:td.error_description||td.message||'Discord token exchange failed'});
    const ur=await fetch('https://discord.com/api/v10/users/@me',{headers:{Authorization:`Bearer ${td.access_token}`}});
    const du=await ur.json().catch(()=>({})); if(!ur.ok||!du.id) return json(401,{error:du.message||'Failed to fetch Discord user'});
    const username=du.global_name||du.username||`User${String(du.id).slice(-4)}`;
    const hash=du.avatar||''; const id=String(du.id);
    const avatarUrl=hash?`https://cdn.discordapp.com/avatars/${id}/${hash}.${String(hash).startsWith('a_')?'gif':'png'}?size=128`:`https://cdn.discordapp.com/embed/avatars/${Number((BigInt(id)>>22n)%6n)}.png`;
    const dbUser=await supabaseUpsert(du,username,avatarUrl);
    const user={id,username,email:du.email||'',avatar:hash,avatarUrl,balance:Number(dbUser.balance||1000),vipLevel:0,vipName:'Member',vipProgress:0};
    return json(200,{token:crypto.randomBytes(32).toString('hex'),user});
  } catch(err) { console.error('Discord auth function failed:',err); return json(500,{error:'Authentication server error',detail:err.message}); }
};
