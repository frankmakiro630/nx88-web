# Netlify Discord OAuth fix

This build fixes `Page Not Found` on `/auth/discord/callback` by rewriting that route to `index.html` while preserving the OAuth query string.

The Discord code exchange now runs in `netlify/functions/discord-auth.js`, so the browser does not receive the client secret.

For production, set `DISCORD_CLIENT_SECRET` in Netlify Environment Variables and rotate any secret that was previously exposed in browser-side code or a public repository.

Discord Developer Portal redirect URL:
`https://celebrated-fairy-a39883.netlify.app/auth/discord/callback`
